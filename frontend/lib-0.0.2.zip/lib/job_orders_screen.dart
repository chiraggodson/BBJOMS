import 'package:flutter/material.dart';

class JobOrdersPage extends StatelessWidget {
  const JobOrdersPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Job Orders',
        style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700),
      ),
    );
  }
}
