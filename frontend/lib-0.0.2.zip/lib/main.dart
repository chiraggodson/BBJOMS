import 'package:flutter/material.dart';

import 'dashboard_screen.dart';
import 'parties_screen.dart';
import 'yarn_screen.dart';
import 'job_orders_screen.dart';

void main() {
  runApp(const BBJOMSApp());
}

class BBJOMSApp extends StatelessWidget {
  const BBJOMSApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BBJOMS',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0B1117),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00BFA6),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
        fontFamily: 'Arial',
      ),
      home: const BBJOMSShell(),
    );
  }
}

class BBJOMSShell extends StatefulWidget {
  const BBJOMSShell({super.key});

  @override
  State<BBJOMSShell> createState() => _BBJOMSShellState();
}

class _BBJOMSShellState extends State<BBJOMSShell> {
  int _selectedIndex = 0;

  final List<_NavigationItem> _navigationItems = const [
    _NavigationItem(
      icon: Icons.dashboard_outlined,
      selectedIcon: Icons.dashboard,
      label: 'Dashboard',
    ),
    _NavigationItem(
      icon: Icons.people_outline,
      selectedIcon: Icons.people,
      label: 'Parties',
    ),
    _NavigationItem(
      icon: Icons.inventory_2_outlined,
      selectedIcon: Icons.inventory_2,
      label: 'Yarn',
    ),
    _NavigationItem(
      icon: Icons.assignment_outlined,
      selectedIcon: Icons.assignment,
      label: 'Job Orders',
    ),
    _NavigationItem(
      icon: Icons.precision_manufacturing_outlined,
      selectedIcon: Icons.precision_manufacturing,
      label: 'Production',
    ),
    _NavigationItem(
      icon: Icons.settings_outlined,
      selectedIcon: Icons.settings,
      label: 'Machines',
    ),
    _NavigationItem(
      icon: Icons.layers_outlined,
      selectedIcon: Icons.layers,
      label: 'Fabric',
    ),
    _NavigationItem(
      icon: Icons.warehouse_outlined,
      selectedIcon: Icons.warehouse,
      label: 'Inventory',
    ),
    _NavigationItem(
      icon: Icons.bar_chart_outlined,
      selectedIcon: Icons.bar_chart,
      label: 'Reports',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final bool compact = MediaQuery.of(context).size.width < 1000;

    return Scaffold(
      body: Row(
        children: [
          _buildSidebar(compact),
          Expanded(
            child: Column(
              children: [
                _buildTopBar(),
                Expanded(
                  child: _buildPage(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSidebar(bool compact) {
    return Container(
      width: compact ? 76 : 235,
      decoration: const BoxDecoration(
        color: Color(0xFF101820),
        border: Border(
          right: BorderSide(
            color: Color(0xFF1D2933),
          ),
        ),
      ),
      child: Column(
        children: [
          const SizedBox(height: 22),

          // Logo
          Padding(
            padding: EdgeInsets.symmetric(
              horizontal: compact ? 12 : 20,
            ),
            child: Row(
              mainAxisAlignment: compact
                  ? MainAxisAlignment.center
                  : MainAxisAlignment.start,
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: const Color(0xFF00BFA6),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(
                    Icons.factory,
                    color: Colors.white,
                    size: 22,
                  ),
                ),
                if (!compact) ...[
                  const SizedBox(width: 12),
                  const Text(
                    'BBJOMS',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ],
            ),
          ),

          const SizedBox(height: 32),

          // Navigation
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              itemCount: _navigationItems.length,
              itemBuilder: (context, index) {
                final item = _navigationItems[index];
                final selected = index == _selectedIndex;

                return Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: _SidebarItem(
                    item: item,
                    selected: selected,
                    compact: compact,
                    onTap: () {
                      setState(() {
                        _selectedIndex = index;
                      });
                    },
                  ),
                );
              },
            ),
          ),

          // Bottom user section
          Container(
            margin: const EdgeInsets.all(12),
            padding: EdgeInsets.all(compact ? 8 : 12),
            decoration: BoxDecoration(
              color: const Color(0xFF151F28),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              mainAxisAlignment: compact
                  ? MainAxisAlignment.center
                  : MainAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 17,
                  backgroundColor: const Color(0xFF00BFA6),
                  child: const Text(
                    'C',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                if (!compact) ...[
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Admin',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Administrator',
                          style: TextStyle(
                            color: Color(0xFF84919D),
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Icon(
                    Icons.more_vert,
                    size: 18,
                    color: Color(0xFF84919D),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopBar() {
    return Container(
      height: 68,
      padding: const EdgeInsets.symmetric(horizontal: 28),
      decoration: const BoxDecoration(
        color: Color(0xFF0F171E),
        border: Border(
          bottom: BorderSide(
            color: Color(0xFF1D2933),
          ),
        ),
      ),
      child: Row(
        children: [
          Text(
            _navigationItems[_selectedIndex].label,
            style: const TextStyle(
              fontSize: 21,
              fontWeight: FontWeight.w600,
            ),
          ),

          const Spacer(),

          // Search
          Container(
            width: 220,
            height: 38,
            decoration: BoxDecoration(
              color: const Color(0xFF151F28),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: const Color(0xFF25313B),
              ),
            ),
            child: const Row(
              children: [
                SizedBox(width: 12),
                Icon(
                  Icons.search,
                  size: 18,
                  color: Color(0xFF71808D),
                ),
                SizedBox(width: 8),
                Text(
                  'Search...',
                  style: TextStyle(
                    color: Color(0xFF71808D),
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(width: 16),

          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.notifications_none),
            tooltip: 'Notifications',
          ),

          const SizedBox(width: 8),

          Container(
            width: 1,
            height: 28,
            color: const Color(0xFF25313B),
          ),

          const SizedBox(width: 16),

          const Text(
            'B&B KnitFab',
            style: TextStyle(
              color: Color(0xFF9BA7B2),
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPage() {
    switch (_selectedIndex) {
      case 0:
        return const DashboardPage();
      case 1:
        return const PartiesPage();
      case 2:
        return const YarnPage();
      case 3:
        return const JobOrdersPage();

      default:
        return _ComingSoonPage(
          title: _navigationItems[_selectedIndex].label,
        );
    }
  }
}

class _SidebarItem extends StatelessWidget {
  final _NavigationItem item;
  final bool selected;
  final bool compact;
  final VoidCallback onTap;

  const _SidebarItem({
    required this.item,
    required this.selected,
    required this.compact,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: compact ? item.label : '',
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          height: 44,
          padding: EdgeInsets.symmetric(
            horizontal: compact ? 0 : 12,
          ),
          decoration: BoxDecoration(
            color: selected
                ? const Color(0xFF00BFA6).withValues(alpha: 0.12)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Row(
            mainAxisAlignment: compact
                ? MainAxisAlignment.center
                : MainAxisAlignment.start,
            children: [
              Icon(
                selected ? item.selectedIcon : item.icon,
                size: 20,
                color: selected
                    ? const Color(0xFF00BFA6)
                    : const Color(0xFF7C8995),
              ),
              if (!compact) ...[
                const SizedBox(width: 12),
                Text(
                  item.label,
                  style: TextStyle(
                    color: selected
                        ? const Color(0xFFE8F2F0)
                        : const Color(0xFF9BA7B2),
                    fontSize: 13,
                    fontWeight:
                        selected ? FontWeight.w600 : FontWeight.w400,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class PartiesPage extends StatefulWidget {
  const PartiesPage({super.key});

  @override
  State<PartiesPage> createState() => _PartiesPageState();
}

class _PartiesPageState extends State<PartiesPage> {
  final TextEditingController _searchController = TextEditingController();

  final List<_Party> _parties = [
    _Party(
      name: 'B&B KNIT FAB',
      roles: ['Customer', 'Job Worker'],
      city: 'Ludhiana',
      state: 'Punjab',
      gstin: '',
      phone: '',
      contact: '',
    ),
    _Party(
      name: 'A.D CLOTHING',
      roles: ['Customer'],
      city: 'Ludhiana',
      state: 'Punjab',
      gstin: '03ABKFA8325H...',
      phone: '',
      contact: '',
    ),
    _Party(
      name: 'A.K.GOYAL HOSIERY',
      roles: ['Customer'],
      city: 'Ludhiana',
      state: 'Punjab',
      gstin: '03ABKPG4650H...',
      phone: '',
      contact: '',
    ),
    _Party(
      name: 'AARADHYA CREATIONS',
      roles: ['Customer'],
      city: 'Ludhiana',
      state: 'Punjab',
      gstin: '03AQRPA0412D...',
      phone: '',
      contact: '',
    ),
    _Party(
      name: 'ADAM KNITS',
      roles: ['Customer'],
      city: 'Ludhiana',
      state: 'Punjab',
      gstin: '03AKFPJ4824Q...',
      phone: '',
      contact: '',
    ),
    _Party(
      name: 'AMIT ENTERPRISES',
      roles: ['Customer'],
      city: 'Ludhiana',
      state: 'Punjab',
      gstin: '03AAJFA2975L...',
      phone: '',
      contact: '',
    ),
    _Party(
      name: 'ANKUSH KNITS',
      roles: ['Customer'],
      city: 'Ludhiana',
      state: 'Punjab',
      gstin: '03AAVCA0500F...',
      phone: '',
      contact: '',
    ),
    _Party(
      name: 'ANSH FABRICS',
      roles: ['Customer'],
      city: 'Ludhiana',
      state: 'Punjab',
      gstin: '03ADHPA8268...',
      phone: '',
      contact: '',
    ),
    _Party(
      name: 'BANI FABRICS',
      roles: ['Customer'],
      city: 'Ludhiana',
      state: 'Punjab',
      gstin: '03ABLPT5283C...',
      phone: '',
      contact: '',
    ),
    _Party(
      name: 'BHARTI FABRICS',
      roles: ['Customer'],
      city: 'Ludhiana',
      state: 'Punjab',
      gstin: '03ABNPJ3788Q...',
      phone: '',
      contact: '',
    ),
    _Party(
      name: 'B.D.S CLOTHING',
      roles: ['Customer'],
      city: 'Ludhiana',
      state: 'Punjab',
      gstin: '03AAJFB5116N...',
      phone: '',
      contact: '',
    ),
    _Party(
      name: 'CHARLEY KNITS',
      roles: ['Customer'],
      city: 'Ludhiana',
      state: 'Punjab',
      gstin: '03AABCC2212...',
      phone: '9814085399',
      contact: '',
    ),
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<_Party> get _filteredParties {
    final query = _searchController.text.trim().toLowerCase();
    if (query.isEmpty) return _parties;

    return _parties.where((party) {
      return party.name.toLowerCase().contains(query) ||
          party.city.toLowerCase().contains(query) ||
          party.roles.any((role) => role.toLowerCase().contains(query));
    }).toList();
  }

  void _openPartyForm() {
    showDialog<void>(
      context: context,
      builder: (_) => const _PartyFormDialog(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final parties = _filteredParties;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Parties',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      'Customers, suppliers, job workers and other business parties',
                      style: TextStyle(
                        color: Color(0xFF84919D),
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
              FilledButton.icon(
                onPressed: _openPartyForm,
                icon: const Icon(Icons.add, size: 18),
                label: const Text('New Party'),
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF00BFA6),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 18,
                    vertical: 14,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          _PartySummary(),
          const SizedBox(height: 20),
          _DashboardCard(
            title: 'Party Master',
            child: Column(
              children: [
                const SizedBox(height: 14),
                TextField(
                  controller: _searchController,
                  onChanged: (_) => setState(() {}),
                  decoration: InputDecoration(
                    hintText: 'Search party, city or role...',
                    prefixIcon: const Icon(Icons.search, size: 20),
                    suffixIcon: _searchController.text.isEmpty
                        ? null
                        : IconButton(
                            onPressed: () {
                              _searchController.clear();
                              setState(() {});
                            },
                            icon: const Icon(Icons.clear, size: 18),
                          ),
                    filled: true,
                    fillColor: const Color(0xFF0F171E),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(9),
                      borderSide: const BorderSide(
                        color: Color(0xFF25313B),
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(9),
                      borderSide: const BorderSide(
                        color: Color(0xFF25313B),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(9),
                      borderSide: const BorderSide(
                        color: Color(0xFF00BFA6),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                if (parties.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(40),
                    child: Column(
                      children: [
                        Icon(
                          Icons.people_outline,
                          size: 42,
                          color: Color(0xFF53616D),
                        ),
                        SizedBox(height: 12),
                        Text(
                          'No parties found',
                          style: TextStyle(
                            color: Color(0xFF9BA7B2),
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  )
                else
                  _PartyTable(parties: parties),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PartySummary extends StatelessWidget {
  const _PartySummary();

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final cards = const [
          ('Total Parties', '136', Icons.people_outline),
          ('Customers', '98', Icons.storefront_outlined),
          ('Job Workers', '21', Icons.precision_manufacturing_outlined),
          ('Suppliers', '17', Icons.local_shipping_outlined),
        ];

        if (constraints.maxWidth < 760) {
          return Wrap(
            spacing: 12,
            runSpacing: 12,
            children: cards.map((card) {
              return SizedBox(
                width: (constraints.maxWidth - 12) / 2,
                child: _PartyStatCard(
                  title: card.$1,
                  value: card.$2,
                  icon: card.$3,
                ),
              );
            }).toList(),
          );
        }

        return Row(
          children: cards
              .map(
                (card) => Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 12),
                    child: _PartyStatCard(
                      title: card.$1,
                      value: card.$2,
                      icon: card.$3,
                    ),
                  ),
                ),
              )
              .toList(),
        );
      },
    );
  }
}

class _PartyStatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _PartyStatCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF111A22),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF1E2A34)),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: const Color(0xFF00BFA6).withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              icon,
              color: const Color(0xFF00BFA6),
              size: 21,
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: Color(0xFF84919D),
                  fontSize: 11,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PartyTable extends StatelessWidget {
  final List<_Party> parties;

  const _PartyTable({required this.parties});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 800;

        if (compact) {
          return Column(
            children: parties.map((party) {
              return Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: const BoxDecoration(
                  border: Border(
                    bottom: BorderSide(color: Color(0xFF1D2933)),
                  ),
                ),
                child: Row(
                  children: [
                    const CircleAvatar(
                      radius: 18,
                      backgroundColor: Color(0xFF153A38),
                      child: Icon(
                        Icons.business_outlined,
                        color: Color(0xFF00BFA6),
                        size: 18,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            party.name,
                            style: const TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 13,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${party.city.isEmpty ? '—' : party.city} • ${party.roles.join(', ')}',
                            style: const TextStyle(
                              color: Color(0xFF71808D),
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(
                      Icons.chevron_right,
                      color: Color(0xFF53616D),
                    ),
                  ],
                ),
              );
            }).toList(),
          );
        }

        return Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 11,
              ),
              decoration: BoxDecoration(
                color: const Color(0xFF0F171E),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: Text(
                      'Party',
                      style: _TableHeaderStyle.style,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      'Role',
                      style: _TableHeaderStyle.style,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      'City',
                      style: _TableHeaderStyle.style,
                    ),
                  ),
                  Expanded(
                    flex: 3,
                    child: Text(
                      'GSTIN',
                      style: _TableHeaderStyle.style,
                    ),
                  ),
                  SizedBox(width: 40),
                ],
              ),
            ),
            ...parties.map(
              (party) => Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 14,
                ),
                decoration: const BoxDecoration(
                  border: Border(
                    bottom: BorderSide(color: Color(0xFF1D2933)),
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: Row(
                        children: [
                          const CircleAvatar(
                            radius: 17,
                            backgroundColor: Color(0xFF153A38),
                            child: Icon(
                              Icons.business_outlined,
                              color: Color(0xFF00BFA6),
                              size: 17,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              party.name,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Wrap(
                        spacing: 5,
                        runSpacing: 4,
                        children: party.roles
                            .map((role) => _RoleChip(role: role))
                            .toList(),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        party.city.isEmpty ? '—' : party.city,
                        style: const TextStyle(
                          color: Color(0xFF9BA7B2),
                          fontSize: 12,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Text(
                        party.gstin.isEmpty ? '—' : party.gstin,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Color(0xFF71808D),
                          fontSize: 11,
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: const Icon(
                        Icons.more_horiz,
                        size: 18,
                        color: Color(0xFF71808D),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _RoleChip extends StatelessWidget {
  final String role;

  const _RoleChip({required this.role});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 7,
        vertical: 4,
      ),
      decoration: BoxDecoration(
        color: const Color(0xFF00BFA6).withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        role,
        style: const TextStyle(
          color: Color(0xFF62D9C9),
          fontSize: 9,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class _TableHeaderStyle {
  static const style = TextStyle(
    color: Color(0xFF71808D),
    fontSize: 10,
    fontWeight: FontWeight.w600,
  );
}

class _Party {
  final String name;
  final List<String> roles;
  final String city;
  final String state;
  final String gstin;
  final String phone;
  final String contact;

  const _Party({
    required this.name,
    required this.roles,
    required this.city,
    required this.state,
    required this.gstin,
    required this.phone,
    required this.contact,
  });
}

class _PartyFormDialog extends StatefulWidget {
  const _PartyFormDialog();

  @override
  State<_PartyFormDialog> createState() => _PartyFormDialogState();
}

class _PartyFormDialogState extends State<_PartyFormDialog> {
  final _formKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _aliasController = TextEditingController();
  final _gstinController = TextEditingController();
  final _address1Controller = TextEditingController();
  final _address2Controller = TextEditingController();
  final _cityController = TextEditingController();
  final _stateController = TextEditingController();
  final _pinController = TextEditingController();
  final _contactController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();

  final Set<String> _roles = {'Customer'};

  static const _availableRoles = [
    'Customer',
    'Yarn Supplier',
    'Job Worker',
    'Processor',
    'Other',
  ];

  @override
  void dispose() {
    for (final controller in [
      _nameController,
      _aliasController,
      _gstinController,
      _address1Controller,
      _address2Controller,
      _cityController,
      _stateController,
      _pinController,
      _contactController,
      _phoneController,
      _emailController,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  InputDecoration _decoration(String label, {String? hint}) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      filled: true,
      fillColor: const Color(0xFF0F171E),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Color(0xFF25313B)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Color(0xFF25313B)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Color(0xFF00BFA6)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF111A22),
      insetPadding: const EdgeInsets.all(24),
      child: ConstrainedBox(
        constraints: const BoxConstraints(
          maxWidth: 900,
          maxHeight: 760,
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 16, 18),
              child: Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'New Party',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Create a business party and assign its roles',
                          style: TextStyle(
                            color: Color(0xFF71808D),
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
            ),
            const Divider(height: 1, color: Color(0xFF25313B)),
            Expanded(
              child: Form(
                key: _formKey,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const _FormSectionTitle(
                        title: 'Basic Information',
                        icon: Icons.business_outlined,
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _nameController,
                        decoration: _decoration('Party Name *'),
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Party name is required';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _aliasController,
                        decoration: _decoration('Print Alias'),
                      ),
                      const SizedBox(height: 18),
                      const Text(
                        'Party Roles',
                        style: TextStyle(
                          color: Color(0xFF9BA7B2),
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: _availableRoles.map((role) {
                          final selected = _roles.contains(role);
                          return FilterChip(
                            label: Text(role),
                            selected: selected,
                            onSelected: (value) {
                              setState(() {
                                if (value) {
                                  _roles.add(role);
                                } else {
                                  _roles.remove(role);
                                }
                              });
                            },
                            selectedColor:
                                const Color(0xFF00BFA6).withValues(alpha: 0.18),
                            checkmarkColor: const Color(0xFF00BFA6),
                            side: const BorderSide(
                              color: Color(0xFF25313B),
                            ),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 24),
                      const _FormSectionTitle(
                        title: 'Tax & Registration',
                        icon: Icons.receipt_long_outlined,
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _gstinController,
                        decoration: _decoration('GSTIN'),
                      ),
                      const SizedBox(height: 24),
                      const _FormSectionTitle(
                        title: 'Address',
                        icon: Icons.location_on_outlined,
                      ),
                      const SizedBox(height: 14),
                      LayoutBuilder(
                        builder: (context, constraints) {
                          final twoColumns = constraints.maxWidth > 650;
                          final width = twoColumns
                              ? (constraints.maxWidth - 14) / 2
                              : constraints.maxWidth;

                          return Wrap(
                            spacing: 14,
                            runSpacing: 14,
                            children: [
                              SizedBox(
                                width: width,
                                child: TextFormField(
                                  controller: _address1Controller,
                                  decoration: _decoration('Address Line 1'),
                                ),
                              ),
                              SizedBox(
                                width: width,
                                child: TextFormField(
                                  controller: _address2Controller,
                                  decoration: _decoration('Address Line 2'),
                                ),
                              ),
                              SizedBox(
                                width: width,
                                child: TextFormField(
                                  controller: _cityController,
                                  decoration: _decoration('City'),
                                ),
                              ),
                              SizedBox(
                                width: width,
                                child: TextFormField(
                                  controller: _stateController,
                                  decoration: _decoration('State'),
                                ),
                              ),
                              SizedBox(
                                width: width,
                                child: TextFormField(
                                  controller: _pinController,
                                  decoration: _decoration('PIN Code'),
                                ),
                              ),
                              SizedBox(
                                width: width,
                                child: TextFormField(
                                  initialValue: 'India',
                                  decoration: _decoration('Country'),
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                      const SizedBox(height: 24),
                      const _FormSectionTitle(
                        title: 'Contact',
                        icon: Icons.contact_phone_outlined,
                      ),
                      const SizedBox(height: 14),
                      LayoutBuilder(
                        builder: (context, constraints) {
                          final twoColumns = constraints.maxWidth > 650;
                          final width = twoColumns
                              ? (constraints.maxWidth - 14) / 2
                              : constraints.maxWidth;

                          return Wrap(
                            spacing: 14,
                            runSpacing: 14,
                            children: [
                              SizedBox(
                                width: width,
                                child: TextFormField(
                                  controller: _contactController,
                                  decoration: _decoration('Contact Person'),
                                ),
                              ),
                              SizedBox(
                                width: width,
                                child: TextFormField(
                                  controller: _phoneController,
                                  decoration: _decoration('Contact Number'),
                                ),
                              ),
                              SizedBox(
                                width: width,
                                child: TextFormField(
                                  controller: _emailController,
                                  decoration: _decoration('Email'),
                                  keyboardType: TextInputType.emailAddress,
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const Divider(height: 1, color: Color(0xFF25313B)),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel'),
                  ),
                  const SizedBox(width: 10),
                  FilledButton(
                    onPressed: () {
                      if (!_formKey.currentState!.validate()) return;
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                            'Party saved locally. Database linking comes next.',
                          ),
                        ),
                      );
                    },
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF00BFA6),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 13,
                      ),
                    ),
                    child: const Text('Save Party'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FormSectionTitle extends StatelessWidget {
  final String title;
  final IconData icon;

  const _FormSectionTitle({
    required this.title,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(
          icon,
          size: 18,
          color: const Color(0xFF00BFA6),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

class YarnPage extends StatefulWidget {
  const YarnPage({super.key});

  @override
  State<YarnPage> createState() => _YarnPageState();
}

class _YarnPageState extends State<YarnPage> {
  final TextEditingController _searchController = TextEditingController();

  final List<_YarnItem> _yarns = [
    _YarnItem(
      name: 'Polyester 75D',
      count: '75D',
      type: 'Polyester',
      stock: 1842,
      lots: 6,
      unit: 'kg',
    ),
    _YarnItem(
      name: 'Polyester 150D',
      count: '150D',
      type: 'Polyester',
      stock: 1268,
      lots: 4,
      unit: 'kg',
    ),
    _YarnItem(
      name: 'Cotton 30s',
      count: '30s',
      type: 'Cotton',
      stock: 932,
      lots: 5,
      unit: 'kg',
    ),
    _YarnItem(
      name: 'Cotton 40s',
      count: '40s',
      type: 'Cotton',
      stock: 714,
      lots: 3,
      unit: 'kg',
    ),
    _YarnItem(
      name: 'Viscose 30s',
      count: '30s',
      type: 'Viscose',
      stock: 486,
      lots: 2,
      unit: 'kg',
    ),
    _YarnItem(
      name: 'Spandex 40D',
      count: '40D',
      type: 'Spandex',
      stock: 238,
      lots: 2,
      unit: 'kg',
    ),
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<_YarnItem> get _filteredYarns {
    final query = _searchController.text.trim().toLowerCase();
    if (query.isEmpty) return _yarns;

    return _yarns.where((yarn) {
      return yarn.name.toLowerCase().contains(query) ||
          yarn.count.toLowerCase().contains(query) ||
          yarn.type.toLowerCase().contains(query);
    }).toList();
  }

  void _openReceiveYarn() {
    showDialog<void>(
      context: context,
      builder: (_) => const _ReceiveYarnDialog(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final yarns = _filteredYarns;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Yarn',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      'Yarn master, lots and live stock',
                      style: TextStyle(
                        color: Color(0xFF84919D),
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
              FilledButton.icon(
                onPressed: _openReceiveYarn,
                icon: const Icon(Icons.add, size: 18),
                label: const Text('Receive Yarn'),
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF00BFA6),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 18,
                    vertical: 14,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          _YarnSummary(),
          const SizedBox(height: 20),
          _DashboardCard(
            title: 'Yarn Stock',
            child: Column(
              children: [
                const SizedBox(height: 14),
                TextField(
                  controller: _searchController,
                  onChanged: (_) => setState(() {}),
                  decoration: InputDecoration(
                    hintText: 'Search yarn, count or type...',
                    prefixIcon: const Icon(Icons.search, size: 20),
                    suffixIcon: _searchController.text.isEmpty
                        ? null
                        : IconButton(
                            onPressed: () {
                              _searchController.clear();
                              setState(() {});
                            },
                            icon: const Icon(Icons.clear, size: 18),
                          ),
                    filled: true,
                    fillColor: const Color(0xFF0F171E),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(9),
                      borderSide: const BorderSide(
                        color: Color(0xFF25313B),
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(9),
                      borderSide: const BorderSide(
                        color: Color(0xFF25313B),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(9),
                      borderSide: const BorderSide(
                        color: Color(0xFF00BFA6),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                if (yarns.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(40),
                    child: Column(
                      children: [
                        Icon(
                          Icons.inventory_2_outlined,
                          size: 42,
                          color: Color(0xFF53616D),
                        ),
                        SizedBox(height: 12),
                        Text(
                          'No yarn found',
                          style: TextStyle(
                            color: Color(0xFF9BA7B2),
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  )
                else
                  _YarnTable(yarns: yarns),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _DashboardCard(
                title: 'Recent Yarn Movements',
                child: const Column(
              children: [
                _YarnMovementRow(
                  icon: Icons.south_west,
                  title: 'Yarn Received',
                  party: 'A.K. Goyal Hosiery',
                  details: 'Lot YR-260818-01 • 420 kg',
                  positive: true,
                ),
                _YarnMovementRow(
                  icon: Icons.north_east,
                  title: 'Yarn Issued',
                  party: 'Job BBJO-00128',
                  details: 'Polyester 75D • 180 kg',
                  positive: false,
                ),
                _YarnMovementRow(
                  icon: Icons.south_west,
                  title: 'Yarn Received',
                  party: 'Sandhir Textiles',
                  details: 'Lot YR-260817-04 • 310 kg',
                  positive: true,
                ),
                _YarnMovementRow(
                  icon: Icons.keyboard_return,
                  title: 'Yarn Returned',
                  party: 'Machine 18 / Job BBJO-00125',
                  details: 'Polyester 150D • 24 kg',
                  positive: true,
                ),
              ],
            ),
              ),
              const SizedBox(height: 4),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () {},
                  child: const Text(
                    'View all movements',
                    style: TextStyle(color: Color(0xFF00BFA6)),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _YarnSummary extends StatelessWidget {
  const _YarnSummary();

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        const cards = [
          ('Total Yarn Stock', '5,480 kg', Icons.inventory_2_outlined),
          ('Active Lots', '22', Icons.layers_outlined),
          ('Received Today', '730 kg', Icons.south_west),
          ('Issued Today', '410 kg', Icons.north_east),
        ];

        if (constraints.maxWidth < 760) {
          return Wrap(
            spacing: 12,
            runSpacing: 12,
            children: cards.map((card) {
              return SizedBox(
                width: (constraints.maxWidth - 12) / 2,
                child: _YarnStatCard(
                  title: card.$1,
                  value: card.$2,
                  icon: card.$3,
                ),
              );
            }).toList(),
          );
        }

        return Row(
          children: cards
              .map(
                (card) => Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 12),
                    child: _YarnStatCard(
                      title: card.$1,
                      value: card.$2,
                      icon: card.$3,
                    ),
                  ),
                ),
              )
              .toList(),
        );
      },
    );
  }
}

class _YarnStatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _YarnStatCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF111A22),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF1E2A34)),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: const Color(0xFF00BFA6).withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              icon,
              color: const Color(0xFF00BFA6),
              size: 21,
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: Color(0xFF84919D),
                  fontSize: 11,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _YarnTable extends StatelessWidget {
  final List<_YarnItem> yarns;

  const _YarnTable({required this.yarns});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 800) {
          return Column(
            children: yarns.map((yarn) {
              return Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: const BoxDecoration(
                  border: Border(
                    bottom: BorderSide(color: Color(0xFF1D2933)),
                  ),
                ),
                child: Row(
                  children: [
                    const CircleAvatar(
                      radius: 18,
                      backgroundColor: Color(0xFF153A38),
                      child: Icon(
                        Icons.all_inclusive,
                        color: Color(0xFF00BFA6),
                        size: 18,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            yarn.name,
                            style: const TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 13,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${yarn.type} • ${yarn.count} • ${yarn.lots} lots',
                            style: const TextStyle(
                              color: Color(0xFF71808D),
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      '${_formatKg(yarn.stock)} kg',
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          );
        }

        return Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 11,
              ),
              decoration: BoxDecoration(
                color: const Color(0xFF0F171E),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: Text(
                      'Yarn',
                      style: _TableHeaderStyle.style,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      'Type',
                      style: _TableHeaderStyle.style,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      'Count',
                      style: _TableHeaderStyle.style,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      'Lots',
                      style: _TableHeaderStyle.style,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      'Stock',
                      style: _TableHeaderStyle.style,
                      textAlign: TextAlign.right,
                    ),
                  ),
                  SizedBox(width: 42),
                ],
              ),
            ),
            ...yarns.map(
              (yarn) => Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 14,
                ),
                decoration: const BoxDecoration(
                  border: Border(
                    bottom: BorderSide(color: Color(0xFF1D2933)),
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: Row(
                        children: [
                          const CircleAvatar(
                            radius: 17,
                            backgroundColor: Color(0xFF153A38),
                            child: Icon(
                              Icons.all_inclusive,
                              color: Color(0xFF00BFA6),
                              size: 17,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              yarn.name,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        yarn.type,
                        style: const TextStyle(
                          color: Color(0xFF9BA7B2),
                          fontSize: 12,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        yarn.count,
                        style: const TextStyle(
                          color: Color(0xFF9BA7B2),
                          fontSize: 12,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        '${yarn.lots}',
                        style: const TextStyle(
                          color: Color(0xFF9BA7B2),
                          fontSize: 12,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        '${_formatKg(yarn.stock)} kg',
                        textAlign: TextAlign.right,
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: const Icon(
                        Icons.more_horiz,
                        size: 18,
                        color: Color(0xFF71808D),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  static String _formatKg(double value) {
    if (value == value.roundToDouble()) {
      return value.toStringAsFixed(0);
    }
    return value.toStringAsFixed(1);
  }
}

class _YarnItem {
  final String name;
  final String count;
  final String type;
  final double stock;
  final int lots;
  final String unit;

  const _YarnItem({
    required this.name,
    required this.count,
    required this.type,
    required this.stock,
    required this.lots,
    required this.unit,
  });
}

class _YarnMovementRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String party;
  final String details;
  final bool positive;

  const _YarnMovementRow({
    required this.icon,
    required this.title,
    required this.party,
    required this.details,
    required this.positive,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Color(0xFF1D2933)),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: (positive
                      ? const Color(0xFF00BFA6)
                      : const Color(0xFFF59E0B))
                  .withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(9),
            ),
            child: Icon(
              icon,
              size: 18,
              color: positive
                  ? const Color(0xFF00BFA6)
                  : const Color(0xFFF59E0B),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  party,
                  style: const TextStyle(
                    color: Color(0xFF9BA7B2),
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          Text(
            details,
            style: const TextStyle(
              color: Color(0xFF71808D),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}

class _ReceiveYarnDialog extends StatefulWidget {
  const _ReceiveYarnDialog();

  @override
  State<_ReceiveYarnDialog> createState() => _ReceiveYarnDialogState();
}

class _ReceiveYarnDialogState extends State<_ReceiveYarnDialog> {
  final _formKey = GlobalKey<FormState>();

  final _yarnController = TextEditingController();
  final _lotController = TextEditingController();
  final _quantityController = TextEditingController();
  final _supplierController = TextEditingController();
  final _remarksController = TextEditingController();

  String _source = 'Purchase';
  String _unit = 'kg';

  @override
  void dispose() {
    _yarnController.dispose();
    _lotController.dispose();
    _quantityController.dispose();
    _supplierController.dispose();
    _remarksController.dispose();
    super.dispose();
  }

  InputDecoration _decoration(String label, {String? hint}) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      filled: true,
      fillColor: const Color(0xFF0F171E),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Color(0xFF25313B)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Color(0xFF25313B)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Color(0xFF00BFA6)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF111A22),
      insetPadding: const EdgeInsets.all(24),
      child: ConstrainedBox(
        constraints: const BoxConstraints(
          maxWidth: 700,
          maxHeight: 650,
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 16, 18),
              child: Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Receive Yarn',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Create a yarn receipt and lot',
                          style: TextStyle(
                            color: Color(0xFF71808D),
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
            ),
            const Divider(height: 1, color: Color(0xFF25313B)),
            Expanded(
              child: Form(
                key: _formKey,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      LayoutBuilder(
                        builder: (context, constraints) {
                          final twoColumns = constraints.maxWidth > 560;
                          final width = twoColumns
                              ? (constraints.maxWidth - 14) / 2
                              : constraints.maxWidth;

                          return Wrap(
                            spacing: 14,
                            runSpacing: 14,
                            children: [
                              SizedBox(
                                width: width,
                                child: DropdownButtonFormField<String>(
                                  initialValue: _source,
                                  decoration: _decoration('Receipt Source'),
                                  items: const [
                                    DropdownMenuItem(
                                      value: 'Purchase',
                                      child: Text('Purchase'),
                                    ),
                                    DropdownMenuItem(
                                      value: 'Customer',
                                      child: Text('Customer'),
                                    ),
                                    DropdownMenuItem(
                                      value: 'Job Worker',
                                      child: Text('Job Worker'),
                                    ),
                                    DropdownMenuItem(
                                      value: 'Opening Stock',
                                      child: Text('Opening Stock'),
                                    ),
                                  ],
                                  onChanged: (value) {
                                    if (value != null) {
                                      setState(() => _source = value);
                                    }
                                  },
                                ),
                              ),
                              SizedBox(
                                width: width,
                                child: TextFormField(
                                  controller: _supplierController,
                                  decoration: _decoration(
                                    'Party / Supplier',
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: width,
                                child: TextFormField(
                                  controller: _yarnController,
                                  decoration: _decoration(
                                    'Yarn',
                                    hint: 'e.g. Polyester 75D',
                                  ),
                                  validator: (value) {
                                    if (value == null ||
                                        value.trim().isEmpty) {
                                      return 'Yarn is required';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              SizedBox(
                                width: width,
                                child: TextFormField(
                                  controller: _lotController,
                                  decoration: _decoration(
                                    'Lot Number',
                                    hint: 'e.g. YR-260818-01',
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: width,
                                child: TextFormField(
                                  controller: _quantityController,
                                  decoration: _decoration('Quantity'),
                                  keyboardType:
                                      const TextInputType.numberWithOptions(
                                    decimal: true,
                                  ),
                                  validator: (value) {
                                    if (value == null ||
                                        double.tryParse(value) == null) {
                                      return 'Enter a valid quantity';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              SizedBox(
                                width: width,
                                child: DropdownButtonFormField<String>(
                                  initialValue: _unit,
                                  decoration: _decoration('Unit'),
                                  items: const [
                                    DropdownMenuItem(
                                      value: 'kg',
                                      child: Text('Kilogram (kg)'),
                                    ),
                                    DropdownMenuItem(
                                      value: 'cone',
                                      child: Text('Cone'),
                                    ),
                                    DropdownMenuItem(
                                      value: 'box',
                                      child: Text('Box'),
                                    ),
                                  ],
                                  onChanged: (value) {
                                    if (value != null) {
                                      setState(() => _unit = value);
                                    }
                                  },
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                      const SizedBox(height: 18),
                      TextFormField(
                        controller: _remarksController,
                        maxLines: 3,
                        decoration: _decoration(
                          'Remarks',
                          hint: 'Optional notes about this receipt',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const Divider(height: 1, color: Color(0xFF25313B)),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel'),
                  ),
                  const SizedBox(width: 10),
                  FilledButton(
                    onPressed: () {
                      if (!_formKey.currentState!.validate()) return;
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                            'Yarn receipt saved locally. Database linking comes next.',
                          ),
                        ),
                      );
                    },
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF00BFA6),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 13,
                      ),
                    ),
                    child: const Text('Receive Yarn'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavigationItem {
  final IconData icon;
  final IconData selectedIcon;
  final String label;

  const _NavigationItem({
    required this.icon,
    required this.selectedIcon,
    required this.label,
  });
}
